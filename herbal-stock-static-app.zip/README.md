# Herbal Production & Stock Management System

Static web app (HTML/CSS/vanilla JS). No build step, no server.

## Run locally
Open `index.html` in a browser, or serve the folder: `python3 -m http.server 8000`.

## Deploy
Upload the folder to any static host: Netlify (drag & drop), GitHub Pages, Cloudflare Pages, Vercel, or Firebase Hosting.

## Data
Records persist in the browser's localStorage (per browser/device). Use Settings > "Reset to sample data" to restore defaults. For multi-user use, connect `persist()` and the load block in `js/app.js` to a backend API.

## Files
- `index.html` - entry point
- `css/styles.css` - design system
- `js/app.js` - app logic, hash routing, views
